package com.example.aplikacjafinal

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.appcompat.app.AppCompatActivity
import android.widget.ImageView
import android.widget.ImageButton
import android.os.Build
import android.os.Bundle
import android.os.AsyncTask
import android.os.Handler
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import android.net.Uri
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import android.widget.TextView
import java.util.*

// Fetch data from ThingSpeak database
class ThingSpeakService(private val listener: ThingSpeakListener) {

    private val alertChannelUrl = "https://api.thingspeak.com/channels/2187577/feeds.json?results=2"
    private val batteryChannelUrl = "https://api.thingspeak.com/channels/2218469/feeds.json?results=2"

    fun fetchData() {
        FetchDataTask().execute(alertChannelUrl, batteryChannelUrl)
    }

    private inner class FetchDataTask : AsyncTask<String, Void, List<JSONObject>>() {
        override fun doInBackground(vararg urls: String): List<JSONObject> {
            val result = mutableListOf<JSONObject>()

            for (url in urls) {
                val json = fetchJsonFromUrl(url)
                json?.let {
                    result.add(it)
                }
            }

            return result
        }

        override fun onPostExecute(result: List<JSONObject>) {
            if (result.size == 2) {
                val alertChannelData = result[0]
                val batteryChannelData = result[1]
                listener.onDataFetched(alertChannelData, batteryChannelData)
            } else {
                listener.onDataFetchFailed()
            }
        }
    }

    private fun fetchJsonFromUrl(urlString: String): JSONObject? {
        var connection: HttpURLConnection? = null
        return try {
            val url = URL(urlString)
            connection = url.openConnection() as HttpURLConnection
            connection.connectTimeout = 5000 // 5 seconds timeout
            val reader = BufferedReader(InputStreamReader(connection.inputStream))
            val buffer = StringBuilder()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                buffer.append(line).append("\n")
            }
            val json = buffer.toString()
            JSONObject(json)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        } finally {
            connection?.disconnect()
        }
    }
}

interface ThingSpeakListener {
    fun onDataFetched(alertChannelData: JSONObject, batteryChannelData: JSONObject)
    fun onDataFetchFailed()
}

// Main Activity content
class MainActivity : AppCompatActivity(), ThingSpeakListener    {

    companion object {
        private const val CHANNEL_ID = "my_channel_id"
    }

    // Handler and Runnable for fetching data every 5 seconds
    private val handler = Handler()
    private val fetchRunnable = object : Runnable {
        override fun run() {

            // Create the notification channel (only needed for Android 8.0 and above)
            createNotificationChannel()

            // Fetch data from ThingSpeak
            ThingSpeakService(this@MainActivity).fetchData()
            handler.postDelayed(this, 10000) // Run every 10 seconds
        }
    }

    // Notification channel
    private fun createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = getString(R.string.channel_name)
            val descriptionText = getString(R.string.channel_description)
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            // Register the channel with the system
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun showNotification(textTitle: String, textContent: String, drawableId: Int) {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(textTitle)
            .setContentText(textContent)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setStyle(NotificationCompat.BigTextStyle().bigText(textContent)) // For displaying long text in the notification

        // You can customize the notification further here if needed.

        val notificationManager = NotificationManagerCompat.from(this)
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return
        }
        notificationManager.notify(/* notificationId */ 1, builder.build())
    }

    // Declare properties to hold the fetched data
    private var firstAlertData: JSONObject? = null
    private var secondAlertData: JSONObject? = null
    private var firstAlertDate: String? = null
    private var secondAlertDate: String? = null
    private var lastBatteryData: JSONObject? = null
    private var batteryDate: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Start fetching data every 3 seconds
        handler.post(fetchRunnable)

        // Set a click listener for Activity2Btn
        val activity2Btn = findViewById<ImageButton>(R.id.Activity2Btn)
        activity2Btn.setOnClickListener {
            val url = "https://thingspeak.com/channels/2187577"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        }
    }

    override fun onDataFetched(alertChannelData: JSONObject, batteryChannelData: JSONObject) {
        val alertFeeds = alertChannelData.getJSONArray("feeds")
        if (alertFeeds.length() >= 2) {
            firstAlertData = alertFeeds.getJSONObject(0)
            secondAlertData = alertFeeds.getJSONObject(1)

            // Correct and format the time for alert channel dates
            firstAlertDate = correctAndFormatTime(firstAlertData!!.getString("created_at"))
            secondAlertDate = correctAndFormatTime(secondAlertData!!.getString("created_at"))
        }

        val batteryFeeds = batteryChannelData.getJSONArray("feeds")
        if (batteryFeeds.length() >= 1) {
            lastBatteryData = batteryFeeds.getJSONObject(batteryFeeds.length() - 1)

            // Correct and format the time for battery channel date
            batteryDate = correctAndFormatTime(lastBatteryData!!.getString("created_at"))
        }

        // Call a function or perform actions that require the fetched data
        processData()
    }

    private fun processData() {
        // Check and update ImageView and TextView based on specific conditions

        // Check conditions for FloodStatusImg
        if ((firstAlertData?.optInt("field1") == 1 || firstAlertData?.optInt("field1") == 210 || firstAlertData?.optInt("field1") == 110) &&
            secondAlertData?.optInt("field1") == 100
        ) {
            findViewById<ImageView>(R.id.FloodStatusImg).setImageResource(R.drawable.allarm)
            showNotification("Flood Sensor Status", "Flood Detected!!! Notification time: $secondAlertDate", R.drawable.flood)
        } else if (firstAlertData?.optInt("field1") == 100 && secondAlertData?.optInt("field1") == 110) {
            findViewById<ImageView>(R.id.FloodStatusImg).setImageResource(R.drawable.check)
            showNotification("Flood Sensor Status", "Flood is over. Notification time: $secondAlertDate", R.drawable.check)
        } else if (firstAlertData?.optInt("field1") == 100 && secondAlertData?.optInt("field1") == 100) {
            findViewById<ImageView>(R.id.FloodStatusImg).setImageResource(R.drawable.allarm)
        } else if (firstAlertData?.optInt("field1") == 110 && secondAlertData?.optInt("field1") == 110) {
            findViewById<ImageView>(R.id.FloodStatusImg).setImageResource(R.drawable.check)
        }

        // Check conditions for UpsStatusImg
        if ((firstAlertData?.optInt("field1") == 1 || firstAlertData?.optInt("field1") == 210 || firstAlertData?.optInt("field1") == 110) &&
            secondAlertData?.optInt("field1") == 200
        ) {
            findViewById<ImageView>(R.id.UpsStatusImg).setImageResource(R.drawable.allarm)
            showNotification("UPS Status", "UPS is ON!!! Notification time: $secondAlertDate", R.drawable.ups)
        } else if (firstAlertData?.optInt("field1") == 200 && secondAlertData?.optInt("field1") == 210) {
            findViewById<ImageView>(R.id.UpsStatusImg).setImageResource(R.drawable.check)
            showNotification("UPS Status", "UPS is OFF. Notification time: $secondAlertDate", R.drawable.check)
        } else if (firstAlertData?.optInt("field1") == 200 && secondAlertData?.optInt("field1") == 200) {
            // Set a default image if no specific conditions are met
            findViewById<ImageView>(R.id.UpsStatusImg).setImageResource(R.drawable.allarm)
        } else if (firstAlertData?.optInt("field1") == 210 && secondAlertData?.optInt("field1") == 210) {
            // Set a default image if no specific conditions are met
            findViewById<ImageView>(R.id.UpsStatusImg).setImageResource(R.drawable.check)
        }

        // Check conditions for RtcStatusImg
        if ((firstAlertData?.optInt("field1") == 1 || firstAlertData?.optInt("field1") == 210 || firstAlertData?.optInt("field1") == 110) &&
            secondAlertData?.optInt("field1") == 10
        ) {
            findViewById<ImageView>(R.id.RtcStatusImg).setImageResource(R.drawable.flood)
            showNotification("RTC Status", "Flood detected!!! Notification time: $secondAlertDate", R.drawable.flood)
        } else if ((firstAlertData?.optInt("field1") == 1 || firstAlertData?.optInt("field1") == 210 || firstAlertData?.optInt("field1") == 110) &&
            secondAlertData?.optInt("field1") == 20
        ) {
            findViewById<ImageView>(R.id.RtcStatusImg).setImageResource(R.drawable.ups)
            showNotification("UPS Status", "UPS is ON!!! Notification time: $secondAlertDate", R.drawable.ups)
        } else if ((firstAlertData?.optInt("field1") == 210 || firstAlertData?.optInt("field1") == 110) &&
            secondAlertData?.optInt("field1") == 1
        ) {
            findViewById<ImageView>(R.id.RtcStatusImg).setImageResource(R.drawable.check)
            showNotification("RTC Status", "Everything is OK. Notification time: $secondAlertDate", R.drawable.check)
        } else if ((firstAlertData?.optInt("field1") == 10 || firstAlertData?.optInt("field1") == 20) &&
            secondAlertData?.optInt("field1") == 1
        ) {
            findViewById<ImageView>(R.id.RtcStatusImg).setImageResource(R.drawable.check)
        } else if (firstAlertData?.optInt("field1") == 1 && secondAlertData?.optInt("field1") == 1
        ) {
            findViewById<ImageView>(R.id.RtcStatusImg).setImageResource(R.drawable.check)
        } else if (firstAlertData?.optInt("field1") == 10 && secondAlertData?.optInt("field1") == 10
        ) {
            findViewById<ImageView>(R.id.RtcStatusImg).setImageResource(R.drawable.flood)
        } else if (firstAlertData?.optInt("field1") == 20 && secondAlertData?.optInt("field1") == 20
        ) {
            findViewById<ImageView>(R.id.RtcStatusImg).setImageResource(R.drawable.ups)
        } else {
            // Set a default image if no specific conditions are met
            findViewById<ImageView>(R.id.RtcStatusImg).setImageResource(R.drawable.check)
        }

        // Check and update BatteryImg and BatteryTxt based on specific conditions
        val lastBatteryValue = lastBatteryData?.optInt("field1") ?: -1
        val batteryImg = findViewById<ImageView>(R.id.BatteryImg)
        val batteryTxt = findViewById<TextView>(R.id.BatteryTxt)

        when {
            ((secondAlertData?.optInt("field1") == 200 || secondAlertData?.optInt("field1") == 20) && lastBatteryValue in 81..100) -> {
                batteryImg.setImageResource(R.drawable.batteryfull)
                batteryTxt.text = "UPS is ON! The actual charge status is: $lastBatteryValue."
            }
            ((secondAlertData?.optInt("field1") == 200 || secondAlertData?.optInt("field1") == 20) && lastBatteryValue in 51..80) -> {
                batteryImg.setImageResource(R.drawable.batterymedium)
                batteryTxt.text = "UPS is ON! The actual charge status is: $lastBatteryValue."
            }
            ((secondAlertData?.optInt("field1") == 200 || secondAlertData?.optInt("field1") == 20) && lastBatteryValue in 1..50) -> {
                batteryImg.setImageResource(R.drawable.batterylow)
                batteryTxt.text = "UPS is ON! The actual charge status is: $lastBatteryValue."
            }
            else -> {
                batteryImg.setImageResource(R.drawable.batterycharging)
                batteryTxt.text = "UPS is OFF. Battery is charging."
            }
        }
    }

    private fun correctAndFormatTime(utcTime: String): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        dateFormat.timeZone = TimeZone.getTimeZone("UTC")
        val date = dateFormat.parse(utcTime)

        val polishTimeZone = TimeZone.getTimeZone("Europe/Warsaw")
        dateFormat.timeZone = polishTimeZone

        return dateFormat.format(date)
    }

    override fun onDataFetchFailed() {
        // Handle the case when data fetching fails
    }

    override fun onDestroy() {
        // Stop fetching data when the activity is destroyed
        handler.removeCallbacks(fetchRunnable)
        super.onDestroy()
    }
}


