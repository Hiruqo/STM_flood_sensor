/*
 * wifi_v2.h
 *
 *  Created on: 13 cze 2023
 *      Author: skobe
 */

#ifndef INC_WIFI_H_
#define INC_WIFI_H_

#include "stm32l4xx_hal.h"

// UART handle
extern UART_HandleTypeDef huart2;

// WiFi Functions
void wifi_init(void);
void wifi_scan_networks(void);

void wifi_sleep_mode(void);
void wifi_active_mode(void);

void wifi_connect_to_network(const char* ssid, const char* password);
void wifi_disconnect_from_network(void);

void wifi_thingspeak_send_data(const char* API_KEY, uint8_t value);

void wifi_get_rtc(int* hours, int* minutes, int* seconds);

#endif /* INC_WIFI_H_ */
