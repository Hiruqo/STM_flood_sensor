/*
 * wifi_v2.c
 *
 *  Created on: 13 cze 2023
 *      Author: skobe
 */

#include "tim.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <wifi.h>

// WiFi module UART buffer
#define WIFI_BUFFER_SIZE 512
uint8_t wifi_buffer[WIFI_BUFFER_SIZE];

// Bool flags
bool OK_init_status = false;				// Init status flag
bool OK_connected_to_network = false; 		// Connect to network flag
bool OK_disconnected_from_network = false;	// Disconnect from network flag
bool OK_got_rtc_data = false;				// Get RTC data from server flag
bool OK_wifi_works = false;					// WiFi works fine flag
bool TS_flag = false;						// ThingSpeak buffer check flag

volatile char* RTC_temp = NULL;				// Helps hold RTC string fragment

// ===============================================================
// ----------------------- Basic functions -----------------------
// ===============================================================

// Clear buffer
void wifi_clear_buffer(void)
{
    HAL_UART_AbortReceive(&huart2);
    memset(wifi_buffer, 0, sizeof(wifi_buffer));
    HAL_UART_Receive_IT(&huart2, wifi_buffer, sizeof(wifi_buffer));
}

// Send a command
void wifi_send_command(const char* command)
{
    HAL_UART_Transmit(&huart2, (uint8_t*)command, strlen(command), HAL_MAX_DELAY);
}

// ===============================================================
// --------------------------- Initial ---------------------------
// ===============================================================
void wifi_init(void)
{
    // Initialize UART peripheral
    __HAL_UART_ENABLE_IT(&huart2, UART_IT_RXNE);
    HAL_UART_Receive_IT(&huart2, wifi_buffer, sizeof(wifi_buffer));

    // Wait for WiFi module to boot
    HAL_Delay(500);

    // Clear UART buffer
    wifi_clear_buffer();

    // ===============================================================
    //  ----------------------------- 1 -----------------------------
    //   ======= AT command to check if module is responding =======
    // ===============================================================
    while(OK_init_status == false)
    {
        wifi_send_command("AT\r\n");
        HAL_Delay(500);
        if(strstr((char*)wifi_buffer, "OK"))
        {
        	// Command Succesfull
        	OK_init_status = true;
        	wifi_clear_buffer();
        }
        wifi_clear_buffer();
    }

    OK_init_status = false;

    // ===============================================================
    //  ----------------------------- 2 -----------------------------
    //   ====== Resets the ESP module to its default settings ======
    // ===============================================================
    while(OK_init_status == false)
    {
        wifi_send_command("AT+RST\r\n");
        HAL_Delay(500);
        if(strstr((char*)wifi_buffer, "OK"))
        {
        	// Command Succesfull
        	OK_init_status = true;
        	wifi_clear_buffer();
        }
        wifi_clear_buffer();
    }

    OK_init_status = false;

    // ===============================================================
    //  ----------------------------- 3 -----------------------------
    //   =============== Disconnect from current AP ================
    // ===============================================================
    while(OK_init_status == false)
    {
        wifi_send_command("AT+CWQAP\r\n");
        HAL_Delay(500);
        if(strstr((char*)wifi_buffer, "OK"))
        {
        	// Command Succesfull
        	OK_init_status = true;
        	wifi_clear_buffer();
        }
        wifi_clear_buffer();
    }

    OK_init_status = false;

    // ===============================================================
    //  ----------------------------- 4 -----------------------------
    //   ==== Set the WiFi mode (Station/SoftAP/Station+SoftAP) ====
    // ===============================================================
    while(OK_init_status == false)
    {
        wifi_send_command("AT+CWMODE=1\r\n");
        HAL_Delay(500);
        if(strstr((char*)wifi_buffer, "OK"))
        {
        	// Command Succesfull
        	OK_init_status = true;
        	wifi_clear_buffer();
        }
        wifi_clear_buffer();
    }

    OK_init_status = false;

    // Initial Complete Signal
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 200);
    HAL_Delay(100);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
}

// ===============================================================
// ---------------------- Scanning Networks ----------------------
// ===============================================================

// MAX Networks number [rows number]
#define MAX_NETWORKS 10

// Networks tab struct
typedef struct {
    char ssid[32];
    int32_t rssi;			// Signal Quality
    uint8_t encryptionType;	// Encryption Type
} WiFiNetwork;

// Function variables
WiFiNetwork wifi_networks[MAX_NETWORKS];
uint8_t num_networks = 0;

// Scan Networks function + create table
void wifi_scan_networks(void)
{
    // Send command
    wifi_send_command("AT+CWLAP\r\n");
    HAL_Delay(5000);

    // Process list of available networks
    char* response = (char*)wifi_buffer;
    char* line = strtok(response, "\r\n");

    num_networks = 0;

    while (line != NULL)
    {
        // Check if the line contains network information
        if (strncmp(line, "+CWLAP:", 7) == 0)
        {
            // Parse network information
            char* ssid_start = strchr(line, '\"') + 1;
            char* ssid_end = strchr(ssid_start, '\"');
            if (ssid_start && ssid_end)
            {
                // Copy SSID to the network structure
                strncpy(wifi_networks[num_networks].ssid, ssid_start, ssid_end - ssid_start);
                wifi_networks[num_networks].ssid[ssid_end - ssid_start] = '\0';

                char* rssi_start = strchr(ssid_end + 1, ',') + 1;
                char* rssi_end = strchr(rssi_start, ',');
                if (rssi_start && rssi_end)
                {
                    // Extract RSSI and convert it to an integer
                    char rssi_str[4];
                    strncpy(rssi_str, rssi_start, rssi_end - rssi_start);
                    rssi_str[rssi_end - rssi_start] = '\0';
                    wifi_networks[num_networks].rssi = atoi(rssi_str);

                    num_networks++;
                    if (num_networks >= MAX_NETWORKS)
                    {
                        // Reached maximum number of networks, exit the loop
                        break;
                    }
                }
            }
        }
        else if (strstr(line, "OK") != NULL)
        {
            // End of response, exit the loop
            break;
        }

        line = strtok(NULL, "\r\n");
    }

    // Clear UART buffer
    wifi_clear_buffer();
}

// ===============================================================
// -------------------- Connecting to Network --------------------
// ===============================================================

// Connect to WiFi Specified Network
void wifi_connect_to_network(const char* ssid, const char* password)
{
	// Command container
    char command[64];

    // Concatenate command with SSID and Password
    snprintf(command, sizeof(command), "AT+CWJAP=\"%s\",\"%s\"\r\n", ssid, password);

    // Connect to WiFi Specified Network
    while(OK_connected_to_network == false)
    {
        wifi_send_command(command);
        HAL_Delay(500);
        if(strstr((char*)wifi_buffer, "WIFI CONNECTED\r\n"))
        {
        	// Command Succesfull
        	OK_connected_to_network = true;
        	wifi_clear_buffer();
        }
        wifi_clear_buffer();
    }

    OK_connected_to_network = false;

    // Set single connection
    wifi_send_command("AT+CIPMUX=0\r\n");
    wifi_clear_buffer();

    // Connection Succesfull Signal
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 200);
	HAL_Delay(100);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
	HAL_Delay(100);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 200);
	HAL_Delay(100);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
}

// ===============================================================
// ----------------- Disconnecting from Network ------------------
// ===============================================================

// Disconnect from current AP
void wifi_disconnect_from_network(void)
{
	// AT+CWQAP command to disconnect from current AP
    while(OK_disconnected_from_network == false)
    {
        wifi_send_command("AT+CWQAP\r\n");
        HAL_Delay(500);
        if(strstr((char*)wifi_buffer, "OK"))
        {
        	// Command Succesfull
        	OK_disconnected_from_network = true;
        	wifi_clear_buffer();
        }
        wifi_clear_buffer();
    }

    OK_disconnected_from_network = false;

    // Dsiconnection Succesfull Signal
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 200);
	HAL_Delay(100);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
	HAL_Delay(100);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 200);
	HAL_Delay(100);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
	HAL_Delay(100);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 200);
	HAL_Delay(100);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
}

// ===============================================================
// ------------------------- ThingSpeak --------------------------
// ===============================================================

// Connection with ThingSpeak
void wifi_thingspeak_send_data(const char* API_KEY, uint8_t value)
{
    // Connect with ThingSpeak
    char command[128];
    // After starting the TCP connection, the connection will be closed automatically after some time, usually after 5 seconds
    // If you want to keep the connection alive, you need to send data within this period (for example, every 15 seconds)
    // The maximum number of fields you can send at once is 8, and the maximum number of characters for each field is 255
    snprintf(command, sizeof(command), "AT+CIPSTART=\"TCP\",\"api.thingspeak.com\",80\r\n");
    wifi_send_command(command);
    HAL_Delay(200);

    // Prepare data to send
    char data[64];
    snprintf(data, sizeof(data), "GET /update?api_key=%s&field1=%d\r\n", API_KEY, value);

    // Send data to ThingSpeak
    snprintf(command, sizeof(command), "AT+CIPSEND=%d\r\n", strlen(data));
    wifi_send_command(command);
    HAL_Delay(200);
    wifi_send_command(data);
    HAL_Delay(200);
    wifi_clear_buffer();

    // Stop TCP connection [ESP12-E doesn't have to close the TCP connection manually.
    // It closes automaticly after 5 seconds period of time]
}

// ===============================================================
// ------------------------- Active/Sleep Mode -------------------
// ===============================================================

// Sleep Mode
void wifi_sleep_mode(void)
{
	// Set Module to Sleep <1 = Modem-Sleep>, <2 = Light-Sleep>
//	wifi_send_command("AT+SLEEP=1\r\n");

	// Set Module to Deep Sleep <0 - inf , 4294967295 = Time [49.7 days]>
	wifi_send_command("AT+GSLP=0\r\n");

	// Clear UART buffer
	wifi_clear_buffer();
}

// Active Mode
void wifi_active_mode(void)
{
	// Set Module Active from Modem-Sleep/Light-Sleep
//	wifi_send_command("AT+SLEEP=0\r\n");

	// Clear UART buffer
//	wifi_clear_buffer();

	// Set Module Active from Deep-Sleep - Reset Pin
	int SLEEP_DELAY = 0;
	while(SLEEP_DELAY < 1500)
	{
		HAL_GPIO_WritePin(WiFi_Reset_GPIO_Port, WiFi_Reset_Pin, SET);
		SLEEP_DELAY++;
	}

	// Reset Pin
	HAL_GPIO_WritePin(WiFi_Reset_GPIO_Port, WiFi_Reset_Pin, RESET);
}

// ===============================================================
// ----------------------------- RTC -----------------------------
// ===============================================================

// Get actual RTC data
void wifi_get_rtc(int* hours, int* minutes, int* seconds)
{
    // Configure ESP8266 as a TCP client and connect to NTP server
	while(OK_got_rtc_data == false)
	{
		wifi_send_command("AT+CIPSTART=\"TCP\",\"time.nist.gov\",13\r\n");
		HAL_Delay(500);
		if(strstr((char*)wifi_buffer, "+IPD,51:"))
		{
			// Allocate memory for RTC_temp and copy the content of wifi_buffer
            RTC_temp = (char*)malloc(strlen((char*)wifi_buffer) + 1);
            strcpy(RTC_temp, (char*)wifi_buffer);

			OK_got_rtc_data = true;
			wifi_clear_buffer();
		}
		wifi_clear_buffer();
	}

	OK_got_rtc_data = false;

    // Search for the time data in the response
    char* response = strstr(RTC_temp, "+IPD,51:");
    char time[9];
    char date[9];
    int year, month, day;
    sscanf(response, "+IPD,51:\n%*s %8s %8s", date, time);
    sscanf(time, "%2d:%2d:%2d", hours, minutes, seconds);
    sscanf(date, "%2d-%2d-%2d", &year, &month, &day);

//    // Determine the month name
//    const char* monthNames[] = {
//        "January", "February", "March", "April", "May", "June",
//        "July", "August", "September", "October", "November", "December"
//    };
//    const char* monthName = monthNames[month - 1];

    HAL_Delay(500);
    wifi_clear_buffer();

    // Between march and
    if(month >= 4 && month <= 10)
    {
    	*hours += 2;
    	if(*hours == 24)
    	{
    		*hours = 0;
    	}
    	else if(*hours == 25)
    	{
    		*hours = 1;
    	}
    }
    else if(month < 4 && month > 10)
    {
    	*hours += 1;
    	if(*hours == 24)
    	{
    		*hours = 0;
    	}
    }

    // Check the connection status -> if STATUS:4 is ok then TCP is disconnected
	while(OK_got_rtc_data == false)
	{
		wifi_send_command("AT+CIPSTATUS\r\n");
		HAL_Delay(500);
		if(strstr((char*)wifi_buffer, "STATUS:4"))
		{
			// Command Succesfull
			OK_got_rtc_data = true;
		    wifi_clear_buffer();
		}
	    wifi_clear_buffer();
	}

    OK_got_rtc_data = false;

    // Initial Complete Signal
     __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 200);
     HAL_Delay(500);
     __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
}



